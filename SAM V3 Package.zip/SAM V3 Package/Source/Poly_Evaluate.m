function [p,dp]=Poly_Evaluate(a0,a,z)

% Vector of polynomial coefficients, a0,a(1),a(2),...a(n)
% z=value at which polynomial is evaluated
% p=value of the polynomial
% dp= value of the derivative

n=length(a);

b(n)=a(n);

c(n)=a(n);

for k=1:n-1;
    
    b(n-k)=b(n-k+1)*z+a(n-k);
    
    c(n-k)=c(n-k+1)*z+b(n-k);
    
end

p=a0+b(1)*z;

dp=c(1);

% End of function