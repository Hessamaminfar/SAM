function [dh,h]=hvap(t);

    T=t+273.16;

    R=8.314/18 ; % kJ/(kg.K);

    a0=4.070; a=[-1.108e-03,4.152e-06,-2.964e-09,0.807e-12];
    
    b0=0.0; b=[4.070,-0.554e-03,1.384e-06,-0.741e-09,0.1614e-12];
    
    [h,dh]=Poly_Evaluate(b0,b,T);
    
    h=h*R; dh=dh*R;
    
    dp=Poly(a0,a,T);
    
    dp=dp*R;
    
  % End of program
    
    