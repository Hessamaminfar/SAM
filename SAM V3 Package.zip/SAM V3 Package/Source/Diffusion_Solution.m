function [Cliquid,Cwater,Temp,Kz,z,x,zm]=Diffusion_Solution(Ts,gm,RH,qvap,qheat,ustar,Lmon,z0,kstyle)

dist=30; Nx=51; Nz=100;  % Set up grid system

zmix=10;

x=linspace(0,dist,Nx);

z=logspace(log10(z0),log10(zmix),Nz);

err=1; errlim=1e-4;
iter=1; iterlimit=50;

%  Initialize temperatures and velocities

for i=1:Nx

    for j=1:Nz;

        Tg=Ts+gm*z(j);

        Temp(i,j)=Tg;

        vel(i,j)=uvel(z(j),ustar,Lmon,z0,0.0);

        Cwater(i,j)=Saturation_Properties(Tg)*RH;

    end

end

Cliquid(1:Nx,1:Nz)=0.0;

Cvapor=Cwater;


% for iter=1:10
while err>errlim &(iter<iterlimit)

    % Estimate eddy diffusivities

    for i=2:Nx

        for j=1:Nz-1;
            
            if kstyle==0

            Kz(i,j)=Keddy_Ri(z(j+1),z(j),Temp(i,j+1),Temp(i,j),vel(i,j+1),vel(i,j),z0);
            
            elseif kstyle==10
                
                Kz(i,j)=Keddy(z(j),ustar,Lmon,0);
                
            else
                
                Kz(i,j)=kstyle;
                
            end

        end

        Cwater(i,:)=Solve_Diffusion(Cwater(i,:),Cwater(i-1,:),Kz(i,:),vel(i,:),x,z,i,qvap);

        Temp(i,:)=Solve_Diffusion(Temp(i,:),Temp(i-1,:),Kz(i,:),vel(i,:),x,z,i,qheat);

    end

    
    for i=1:Nx

        for j=1:Nz

            [Cvap(i,j),Clq(i,j),Tout(i,j)]=Condense(Cwater(i,j),Temp(i,j));

        end

    end

    err=max(max(abs(Clq-Cliquid)))/(max(max(Clq))+1.0e-8);

    Cliquid=Clq;

    Temp=Tout;
    
    iter=iter+1;

end


for j=1:Nz-1

    zm(j)=(z(j+1)+z(j))/2;

end


% End of program