function varargout = SFRungui(varargin)
% SFRUNGUI M-file for SFRungui.fig
%      SFRUNGUI, by itself, creates a new SFRUNGUI or raises the existing
%      singleton*.
%
%      H = SFRUNGUI returns the handle to a new SFRUNGUI or the handle to
%      the existing singleton*.
%
%      SFRUNGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SFRUNGUI.M with the given input arguments.
%
%      SFRUNGUI('Property','Value',...) creates a new SFRUNGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SFRungui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SFRungui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SFRungui

% Last Modified by GUIDE v2.5 11-Feb-2014 19:42:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @SFRungui_OpeningFcn, ...
    'gui_OutputFcn',  @SFRungui_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SFRungui is made visible.
function SFRungui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SFRungui (see VARARGIN)

% Choose default command line output for SFRungui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SFRungui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SFRungui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function num1_Callback(hObject, eventdata, handles)
% hObject    handle to num1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num1 as text
%        str2double(get(hObject,'String')) returns contents of num1 as a double


% --- Executes during object creation, after setting all properties.
function num1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num2_Callback(hObject, eventdata, handles)
% hObject    handle to num2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num2 as text
%        str2double(get(hObject,'String')) returns contents of num2 as a double


% --- Executes during object creation, after setting all properties.
function num2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num3_Callback(hObject, eventdata, handles)
% hObject    handle to num3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num3 as text
%        str2double(get(hObject,'String')) returns contents of num3 as a double


% --- Executes during object creation, after setting all properties.
function num3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num4_Callback(hObject, eventdata, handles)
% hObject    handle to num4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num4 as text
%        str2double(get(hObject,'String')) returns contents of num4 as a double


% --- Executes during object creation, after setting all properties.
function num4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num6_Callback(hObject, eventdata, handles)
% hObject    handle to num6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num6 as text
%        str2double(get(hObject,'String')) returns contents of num6 as a double


% --- Executes during object creation, after setting all properties.
function num6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num7_Callback(hObject, eventdata, handles)
% hObject    handle to num7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num7 as text
%        str2double(get(hObject,'String')) returns contents of num7 as a double


% --- Executes during object creation, after setting all properties.
function num7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num8_Callback(hObject, eventdata, handles)
% hObject    handle to num8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num8 as text
%        str2double(get(hObject,'String')) returns contents of num8 as a double


% --- Executes during object creation, after setting all properties.
function num8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num5_Callback(hObject, eventdata, handles)
% hObject    handle to num5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num5 as text
%        str2double(get(hObject,'String')) returns contents of num5 as a double


% --- Executes during object creation, after setting all properties.
function num5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

temp_units = get(handles.popupmenu2,'value');
%orignal code if for kelvins so must convert to Kelvin
Ts=str2num(get(handles.num3,'string'));
switch temp_units
    case 1%fahrenhieght
        Ts=Ts-32;
        Ts=Ts*5/9;
        Ts=Ts+273.15;
    case 2%celcius
        Ts=(Ts+273.15);
    case 3%kelvin
        Ts=Ts;
    otherwise
end

%convert from string 2 number

gm=3*1e-3;

qheat=1*1e-3;

RH=str2num(get(handles.num5,'string'))/100;

Ts=str2num(get(handles.num3,'string'));
% qvap=str2num(get(handles.num1,'string'))*1e-3;

ustar=0.44704*0.1*str2num(get(handles.num6,'string'));%input velocity [m/s]

% Lmon=str2num(get(handles.num7,'string'));
% z0=str2num(get(handles.num8,'string'));
fmc_cond=get(handles.fmc_tag,'Value');

switch fmc_cond%fmc
    
    case 1
        fmc=1;
        
    case 2
        fmc=2;
        
    otherwise
end

FL=get(handles.FuelLoad,'Value');

switch FL%fuel loading
    
    case 1
        qvap=.25*fmc*1e-3;
        z0=.5;
        
    case 2
        
        qvap=.25*fmc*1e-3;
        z0=.25;
        
    case 3
        
        qvap=.05*fmc*1e-3;
        z0=.03;
        
    otherwise
end

stability=get(handles.popupmenu5,'Value');%stability

switch stability;
    
    case 1
        Lmon=20;
        
    case 2
        
        Lmon=100;
        
    case 3
        
        Lmon=1000;
        
    otherwise
end




% USunits=get(handles.radiobutton2,'Value');


% qvap=1.6e-3;qheat=1e-3;ustar=.1;Lmon=100;z0=0.01;
% 
% %these valuse will depend on the experiment
% Ts=10+273.15; %1.66 for Gainsville
% %10 for Polk County I-4
% gm=30;
% RH=.85;         %.90 for Gainsville
% %.85 for Polk County I-4

[Cliquid,Cwater,Temp,Kz,z,x,zm]=Diffusion_Solution(Ts,gm,RH,qvap,qheat,ustar,Lmon,z0,0);

for i=1:length(x)

    Cliqmax_x(i)=max(Cliquid(i,:));
    if Cliqmax_x(i)<0
        Cliqmax_x(i)=0;
    end

    for j=1:length(z)

        if Cliquid(i,j)<2e-3  %2 g/kg

            Cliq_profile(i)=z(j);

            break
        end

    end
end

%recomdendations
b=Cliq_profile(length(Cliq_profile));
b=num2str(b);
superfogheight_SIunits=[b ' m'];
% set(handles.SFheight,'string',superfogheight_SIunits);


if Cliq_profile(length(Cliq_profile))>=1
    c='Superfog is very likely!';
elseif Cliq_profile(length(Cliq_profile))<1 && Cliq_profile(length(Cliq_profile))>=.5
    c='Superfog is possible';
elseif Cliq_profile(length(Cliq_profile))<.5 && Cliq_profile(length(Cliq_profile))>=.1
    c='Superfog is not likely';
elseif Cliq_profile(length(Cliq_profile))<.1
    c='Zero Superfog Threat';
end
set(handles.SFindicator,'string',c);

%% Plots
% if USunits==1%condition to use US unit system
%     
%     x=x*3.28084;%convert meter to feet
%     Cliq_profile=Cliq_profile*3.28084;%covert meter(y) to feet(yaxis)
%     z=z*3.28084;
%     Temp=(Temp-273.15)*1.8+32;%convert temperature from K to F
%     
%     %fig1
% p=polyfit(x,Cliq_profile,15);
% Cliq_pfit=polyval(p,x);
% plot(x,Cliq_profile,'sq',x,Cliq_pfit,'Parent',handles.fig1)
% legend(handles.fig1,'2 g/kg','polyfit')
% ylabel(handles.fig1,'height [ft]');xlabel(handles.fig1,'downwind dist [ft]')
% grid(handles.fig1,'on')
% %fig2
% plot(Cliquid(3,:)*1000,z,Cliquid(18,:)*1000,z,Cliquid(35,:)*1000,z,Cliquid(51,:)*1000,z,'Parent',handles.fig2);
% ylim(handles.fig2,[0 1]);
% xlabel(handles.fig2,'LWC [g m^-^3]'); ylabel(handles.fig2,'Height [ft]');
% grid(handles.fig2,'on');
% legend(handles.fig2,'3.3 ft','30 ft','66 ft','98 ft')
% %fig3
% plot(Temp(3,:),z,Temp(18,:),z,Temp(35,:),z,Temp(51,:),z,'Parent',handles.fig3);
% ylim(handles.fig3,[0 1]);
% xlabel(handles.fig3,'Temperature [F]'); ylabel(handles.fig3,'Height, [ft]');
% grid(handles.fig3,'on');
% legend(handles.fig3,'3.3 ft','30 ft','66 ft','98 ft')
% %fig4
% plot(Cwater(3,:)*1000,z,Cwater(18,:)*1000,z,Cwater(35,:)*1000,z,Cwater(51,:)*1000,z,'Parent',handles.fig4);
% ylim(handles.fig4,[0 1]);
% xlabel(handles.fig4,'w, mixing ratio [g kg^-^1]'); ylabel(handles.fig4,'Height [ft]');
% grid(handles.fig4,'on');
% legend(handles.fig4,'3.3 ft','30 ft','66 ft','98 ft')
% 
% else %condition to use SI unit system
%     
%     
% %fig1
% % clf(handles.fig1,'reset')
% p=polyfit(x,Cliq_profile,15);
% Cliq_pfit=polyval(p,x);
% plot(x,Cliq_profile,'sq',x,Cliq_pfit,'Parent',handles.fig1)
% legend(handles.fig1,'2 g/kg','polyfit')
% ylabel(handles.fig1,'height [m]');xlabel(handles.fig1,'downwind dist [m]')
% grid(handles.fig1,'on')
% %fig2
% plot(Cliquid(3,:)*1000,z,Cliquid(18,:)*1000,z,Cliquid(35,:)*1000,z,Cliquid(51,:)*1000,z,'Parent',handles.fig2);
% ylim(handles.fig2,[0 1]);
% xlabel(handles.fig2,'LWC [g m^-^3]'); ylabel(handles.fig2,'Height [m]');
% grid(handles.fig2,'on');
% legend(handles.fig2,'1m','10m','20m','30m')
% %fig3
% plot(Temp(3,:),z,Temp(18,:),z,Temp(35,:),z,Temp(51,:),z,'Parent',handles.fig3);
% ylim(handles.fig3,[0 1]);
% xlabel(handles.fig3,'Temperature [K]'); ylabel(handles.fig3,'Height, [m]');
% grid(handles.fig3,'on');
% legend(handles.fig3,'1m','10m','20m','30m')
% %fig4
% plot(Cwater(3,:)*1000,z,Cwater(18,:)*1000,z,Cwater(35,:)*1000,z,Cwater(51,:)*1000,z,'Parent',handles.fig4);
% ylim(handles.fig4,[0 1]);
% xlabel(handles.fig4,'w, mixing ratio [g kg^-^1]'); ylabel(handles.fig4,'Height [m]');
% grid(handles.fig4,'on');
% legend(handles.fig4,'1m','10m','20m','30m')
% end

% loglog(Kz(3,:),z(1:length(z)-1),Kz(18,:),z(1:length(z)-1),Kz(35,:),z(1:length(z)-1),Kz(51,:),z(1:length(z)-1),'Parent',handles.fig4);
% xlabel(handles.fig4,'Kz [m^2 s^-^1]'); ylabel(handles.fig4,'Height [m]');
% grid(handles.fig4,'on');
%end
a='finish';
set(handles.ans,'string',a);





% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% help button
    a=imread('SAMhelpfig1.jpg');
    figure(2)
    imshow(a);


% --- Executes during object creation, after setting all properties.
function fig1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fig1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate fig1
% imshow('I4.jpg');




% --- Executes during object creation, after setting all properties.
function fig2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fig2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate fig2
% imshow('Suffolk.png')



% --- Executes during object creation, after setting all properties.
function fig3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fig3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate fig3
% imshow('Gainsville.png')



% --- Executes during object creation, after setting all properties.
function fig4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fig4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate fig4
% imshow('ncforestservice.jpg')


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in FuelLoad.
function FuelLoad_Callback(hObject, eventdata, handles)
% hObject    handle to FuelLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns FuelLoad contents as cell array
%        contents{get(hObject,'Value')} returns selected item from FuelLoad


        


% --- Executes during object creation, after setting all properties.
function FuelLoad_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FuelLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5




% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in fmc_tag.
function fmc_tag_Callback(hObject, eventdata, handles)
% hObject    handle to fmc_tag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns fmc_tag contents as cell array
%        contents{get(hObject,'Value')} returns selected item from fmc_tag



% --- Executes during object creation, after setting all properties.
function fmc_tag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fmc_tag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
