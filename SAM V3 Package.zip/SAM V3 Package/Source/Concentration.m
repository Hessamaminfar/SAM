function Csurf=Concentration(Cinit,x,z,jrc,qsource,z0,dh,ustar,Lmon)
    
    delx=x(2)-x(1);
    
    Nx=length(x); Nz=length(z);
    
    for j=1:Nz;   % Compute diffusivities and velocities
        
        K(j)=Keddy(z(j),ustar,Lmon,dh);
        
        uv(j)=uvel(z(j),ustar,Lmon,z0,dh);
        
    end  
    
    Conc(1:Nx,1:Nz)=Cinit; % Initialize concentrations
    
    % Assign boundary elements of tridiag matrix
    
    Ksurf=(K(1)+K(2))*0.5;
    
    beta=qsource*(z(2)-z(1))/Ksurf;
    
    e(1)=0.0; f(1)=1.0;g(1)=-1; h(1)=beta;
    
    e(Nz)=1.0; f(Nz)=-1; g(Nz)=0.0; h(Nz)=0.0;
    
    alpha(1)=(K(2)+K(1))/(z(2)-z(1));
    
    for j=2:Nz-1;
            
        zup=z(j+1)-z(j);
            
        zdif=z(j+1)-z(j-1);
        
        alpha(j)=(K(j+1)+K(j))/zup;
            
        delt=delx/uv(j)/zdif;      
             
        e(j)=-alpha(j-1)*delt; g(j)=-alpha(j)*delt;
            
        f(j)=(1-e(j)-g(j));
        
    end
    
    for i=2:Nx;
        
        for j=2:Nz-1;
                      
            h(j)=Conc(i-1,j);
            
        end
        
            Conc(i,:)=Tridiag_Solver(e,f,g,h);
            
     end
        
        Conc(:,1)=Conc(:,2)+beta;
        
        Conc(:,Nz)=Conc(:,Nz-1);
     
        Csurf=(Conc(:,jrc)+Conc(:,jrc+1))*0.5;
      
 %   End of program
            
            
    
    
    