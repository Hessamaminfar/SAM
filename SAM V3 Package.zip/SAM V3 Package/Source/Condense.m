function [Cvap,Cliquid,Tout]=Condense(Cwater,Tin)

    errlimit=1.0e-04; iterlimit=10; delt=0.1;
    
    iter=1; err=10;
    
    Cliquid=0.0; Cvap=Cwater; Tout=Tin;
    
    Csat=Saturation_Properties(Tin);
    
    if (Cwater>Csat)
        
        Cliquid=(Cwater-Csat); 
        
        tm=Tin;
        
        while (err>errlimit)&(iter<iterlimit)
        
            f=tm-Tin-Cliquid*2400;
            
            dpsat=(Saturation_Properties(tm+delt)-Saturation_Properties(tm))/delt;
            
            df=1+dpsat*2400;
            
            tmnew=tm-f/df;
        
            Csat=Saturation_Properties(tmnew);
        
            Cliquid=(Cwater-Csat);
        
            err=abs((tmnew-tm)/tm);
        
            tm=tmnew; iter=iter+1;
            
        end
        
        Tout=tmnew; 
        
        Cvap=Csat;
    
    end
        
        
        
        