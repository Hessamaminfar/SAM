function Conc=Solve_Diffusion(Cinit,Cupwind,K,uv,x,z,i,qsource)
    
    delx=x(2)-x(1);
    
    Nx=length(x); Nz=length(z); 
    
    Conc=Cinit; % Initialize concentrations
    
    fblength=1e3;
    
    % Assign boundary elements of tridiag matrix
    
    Ksurf=K(1);
    
    beta=qsource*(z(2)-z(1))/Ksurf;
    
%     if x(i)>fblength
% 
%         e(1)=0.0; f(1)=1.0;g(1)=-1; h(1)=0;
%     
%     else

        e(1)=0.0; f(1)=1.0;g(1)=-1; h(1)=beta;
    
%     end
    
    e(Nz)=1.0; f(Nz)=-1; g(Nz)=0.0; h(Nz)=0.0;
    
    alpha(1)=K(1)/(z(2)-z(1));
    
   
    for j=2:Nz-1;
            
        zup=z(j+1)-z(j);
            
        zdif=z(j+1)-z(j-1);
        
        alpha(j)=2*K(j)/zup;
            
        delt=delx/uv(j)/zdif;      
             
        e(j)=-alpha(j-1)*delt; g(j)=-alpha(j)*delt;
            
        f(j)=(1-e(j)-g(j));
        
    end
       
     for j=2:Nz-1;
                      
         h(j)=Cupwind(j);
            
     end
        
     Conc=Tridiag_Solver(e,f,g,h);
            
        
     Conc(1)=Conc(2)+beta;
        
     Conc(Nz)=Conc(Nz-1);
     
      
 %   End of program
            
            
    
    
    