function p=Poly(a0,a,z)

% Vector of polynomial coefficients, a0,a(1),a(2),...a(n)
% z=value at which polynomial is evaluated
% p=value of the polynomial
% dp= value of the derivative

n=length(a);

b(n)=a(n);

for k=1:n-1;
    
    b(n-k)=b(n-k+1)*z+a(n-k);
    
end

p=a0+b(1)*z;


% End of function