function w=uvel(z,ustar,L,z0,dh)

    kappa=0.4;
    
    psi=(z-dh)/L;
    
    if psi>0.0;
        
        phi=-4.7*psi;
        
    else
        
        x=(1-15*psi)^0.25;
        
        phi=2*log((1+x)/2)+log((1+x*x)/2)-2*atan(x)+pi/2;
        
    end
    
    w=ustar*(log((z-dh)/z0)-phi)/kappa;
    
 
 %  End of program