function Kz=Keddy_Ri(zt,zb,Tempt,Tempb,velt,velb,z0)

    kappa=0.4; g=9.81; Lmon=100;
    
    delz=zt-zb; To=(Tempt+Tempb)*0.5;
    
    grad_temp=(Tempt-Tempb)/delz;
    
    grad_vel=(velt-velb)/delz;
    
    Ri=g/To*grad_temp/(grad_vel*grad_vel);
    
    fac=max(0.0,(1-5*Ri));
    
    lmix=kappa*min((zt+zb)/2,Lmon);
    
    Kz=grad_vel*lmix*lmix*fac^0.5;
    
   
 %  End of program