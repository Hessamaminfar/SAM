function [w3,t3,wlq]=Mixture_Properties(ph1,t1,m1,ph2,t2,m2);

    errlimit=1.0e-04; iterlimit=10; delt=0.1;

    w1=Saturation_Properties(t1)*ph1;
    
    w2=Saturation_Properties(t2)*ph2;

    t3=(m1*t1+m2*t2)/(m1+m2);
    
    w3=(m1*w1+m2*w2)/(m1+m2);
    
    wsat=Saturation_Properties(t3);
    
    wlq=0.0;
    
    if (w3>wsat)
        
        wlq=(w3-wsat); iter=1; err=10;
        
        tm=t3;
        
        while (err>errlimit)&(iter<iterlimit)
        
            f=tm-t3-wlq*1.0e-03*2400;
            
            dpsat=(Saturation_Properties(tm+delt)-Saturation_Properties(tm))/delt;
            
            df=1+dpsat*1.0e-03*2400;
            
            tmnew=tm-f/df;
        
            wsat=Saturation_Properties(tmnew);
        
            wlq=(w3-wsat);
        
            err=abs((tmnew-tm)/tm);
        
            tm=tmnew; iter=iter+1;
            
        end
        
        t3=tmnew; 
        
        w3=wsat;
    
    end
        
        
        
        