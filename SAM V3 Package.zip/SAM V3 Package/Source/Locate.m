function jb=Locate(v,vs);

    N=length(v);
    
    jb=1; jt=N;
    
    jm=round((jb+jt)/2);
    
    while (jt-jb)>1;
    
        mid=v(jm);
    
        if vs>=mid;
        
            jb=jm;
        
        else
        
            jt=jm;
        
        end
        
        jm=round((jb+jt)/2);
        
    end
    
 %  End of program
        
        